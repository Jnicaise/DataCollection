#Requires -Version 7.4
[CmdletBinding()]
param ()

$ErrorActionPreference = 'Stop'
$requiredModules = @(
    @{ Name = 'PSRule'; Version = [version]'2.9.0' }
    @{ Name = 'PSRule.Rules.Azure'; Version = [version]'1.47.0' }
)

foreach ($requiredModule in $requiredModules) {
    $manifestPath = Join-Path $PSScriptRoot "modules/$($requiredModule.Name)/$($requiredModule.Version)/$($requiredModule.Name).psd1"
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw "Bundled module missing: $manifestPath. Transfer the complete offline-psrule folder; no download will be attempted."
    }
    foreach ($loadedModule in @(Get-Module -Name $requiredModule.Name)) {
        if ($loadedModule.Version -ne $requiredModule.Version -or $loadedModule.ModuleBase -ne (Split-Path $manifestPath -Parent)) {
            throw "$($requiredModule.Name) is already loaded from another location/version. Start a fresh PowerShell session to use the bundle."
        }
    }
}

foreach ($requiredModule in $requiredModules) {
    $manifestPath = Join-Path $PSScriptRoot "modules/$($requiredModule.Name)/$($requiredModule.Version)/$($requiredModule.Name).psd1"
    Import-Module -Name $manifestPath -Global -ErrorAction Stop
}

foreach ($commandName in @('Export-AzRuleData', 'Invoke-PSRule')) {
    if (-not (Get-Command -Name $commandName -ErrorAction SilentlyContinue)) {
        throw "Bundled PSRule command is unavailable: $commandName"
    }
}